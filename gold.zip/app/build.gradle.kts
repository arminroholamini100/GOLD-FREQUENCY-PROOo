plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.goldfrequencypro"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.goldfrequencypro"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.1.1"
    }
}
