package com.goldfrequencypro

import android.app.Activity
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : Activity() {
    private enum class Waveform(val label: String) {
        SINE("سینوسی"), SQUARE("مربعی"), SAWTOOTH("اره‌ای")
    }
    private val bg = Color.rgb(16, 17, 20)
    private val panel = Color.rgb(31, 33, 38)
    private val gold = Color.rgb(225, 181, 64)

    @Volatile private var frequencyA = 15000.0
    @Volatile private var frequencyB = 12000.0
    @Volatile private var amplitudeA = 0.25f
    @Volatile private var amplitudeB = 0.25f
    @Volatile private var waveformA = Waveform.SINE
    @Volatile private var waveformB = Waveform.SINE
    @Volatile private var scanEnabled = false
    private var scanStartedNanos = 0L
    private var track: AudioTrack? = null
    private var worker: Thread? = null
    private val running = AtomicBoolean(false)

    private lateinit var frequencyTextA: TextView
    private lateinit var frequencyTextB: TextView
    private lateinit var statusText: TextView
    private lateinit var seekA: SeekBar
    private lateinit var seekB: SeekBar
    private lateinit var startButton: Button
    private lateinit var scanButton: Button
    private var selectedBankFrequency = 25.50

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(24))
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(base)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "GOLD FREQUENCY PRO"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(gold)
            gravity = Gravity.CENTER
        }
        base.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "مولد دوکاناله مستقل استریو AUX"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(18))
        }
        base.addView(subtitle, matchWrap())

        val note = TextView(this).apply {
            text = "کانال A از خروجی چپ (L) و کانال B از خروجی راست (R) پخش می‌شود. این برنامه مولد سیگنال صوتی آزمایشی است و به‌تنهایی فلز یا حفره را شناسایی نمی‌کند."
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        base.addView(note, matchWrap())

        val heading = TextView(this).apply {
            text = "انتخاب حالت آزمایشی"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(gold)
            setPadding(0, dp(20), 0, dp(10))
        }
        base.addView(heading, matchWrap())

        val targets = listOf(
            "طلای جدید" to 12000, "طلای قدیم" to 15000,
            "نقره" to 15000, "کوزه" to 10000,
            "حفره چاه" to 13000, "حفره تونل" to 16000,
            "ورودی تونل" to 18000
        )
        val grid = GridLayout(this).apply { columnCount = 2 }
        targets.forEach { (name, hz) ->
            val b = Button(this).apply {
                text = "$name\n${hz} Hz"
                textSize = 14f
                setTextColor(gold)
                setBackgroundColor(panel)
                setOnClickListener { setFrequencyA(hz.toDouble()) }
            }
            val lp = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(66)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            grid.addView(b, lp)
        }
        base.addView(grid, matchWrap())

        addFrequencyBank(base)

        addChannelControls(base, "کانال A — خروجی چپ AUX (L)", true)
        addChannelControls(base, "کانال B — خروجی راست AUX (R)", false)

        scanButton = Button(this).apply {
            text = "شروع اسکن خودکار کانال A"
            setTextColor(gold)
            setBackgroundColor(panel)
            setOnClickListener {
                scanEnabled = !scanEnabled
                if (scanEnabled) {
                    scanStartedNanos = System.nanoTime()
                    text = "توقف اسکن خودکار کانال A"
                    statusText.text = if (running.get()) "اسکن کانال A فعال است؛ کانال B مستقل می‌ماند" else "اسکن آماده است؛ برای شنیدن خروجی شروع را بزنید"
                } else {
                    text = "شروع اسکن خودکار کانال A"
                    statusText.text = if (running.get()) "تولید دو کانال با فرکانس ثابت" else "متوقف"
                }
            }
        }
        val scanLp = matchWrap().apply { topMargin = dp(10) }
        base.addView(scanButton, scanLp)

        val scanInfo = TextView(this).apply {
            text = "اسکن رفت‌وبرگشتی فقط روی کانال A: از ۱۰٬۰۰۰ تا ۲۰٬۰۰۰ هرتز؛ کانال B مستقل است."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(4))
        }
        base.addView(scanInfo, matchWrap())

        startButton = Button(this).apply {
            text = "شروع تولید دوکاناله"
            setTextColor(Color.BLACK)
            setBackgroundColor(gold)
            setOnClickListener { if (running.get()) stopTone() else startTone() }
        }
        val buttonLp = matchWrap().apply { topMargin = dp(18) }
        base.addView(startButton, buttonLp)

        statusText = TextView(this).apply {
            text = "متوقف"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        base.addView(statusText, matchWrap())

        val route = TextView(this).apply {
            text = "خروجی استریو: فیش AUX چهارکنتاکت نیست؛ از فیش هدفون استریو TRS استفاده کنید. برای تفکیک دو کانال، دستگاه پخش و کابل باید استریو باشند."
            setTextColor(Color.LTGRAY)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        }
        base.addView(route, matchWrap())
    }

    private fun addFrequencyBank(base: LinearLayout) {
        val bank = linkedMapOf(
            "طلا" to (listOf(25.50,37.32,37.33,45.05,47.19,55.09,47.00,55.80,55.84,55.85,61.00,62.00,83.00,610.0,612.0,1006.0,1010.0,1013.0,1070.0,1106.0,1155.0,1325.0,1405.0,1418.0,1812.0,18000.0,59000.0)),
            "مس" to listOf(27.57,295.0,995.0,1090.0),
            "ذرات مس" to (4640..4647).map { it / 10.0 },
            "مفرق" to (4870..4879).map { it / 10.0 },
            "نقره" to listOf(42.55,466.0),
            "الماس" to listOf(45.01,550.0),
            "زمرد" to listOf(1247.0),
            "شیشه" to listOf(36.25),
            "آهن" to listOf(1761.0),
            "سفال" to listOf(91.75,488.0),
            "کربن" to listOf(39.05),
            "دندان" to listOf(710.0),
            "استخوان" to listOf(360.5,361.0,362.1,360.3),
            "آهنربا" to listOf(79.35,79.40,61.22,612.0,1080.0,1795.0,1797.0)
        )
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        base.addView(card, matchWrap().apply { topMargin = dp(14) })
        val heading = TextView(this).apply {
            text = "بانک کامل فرکانس‌های ثبت‌شده"
            textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(gold); gravity = Gravity.CENTER
        }
        card.addView(heading, matchWrap())
        val category = Spinner(this)
        category.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, bank.keys.toList())
        card.addView(category, matchWrap())
        val values = Spinner(this)
        fun refreshValues(index: Int) {
            val list = bank.values.elementAt(index)
            values.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                list.map { "${formatHz(it)} Hz" })
            selectedBankFrequency = list.first()
        }
        category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = refreshValues(position)
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        values.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedBankFrequency = bank.values.elementAt(category.selectedItemPosition)[position]
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        card.addView(values, matchWrap())
        val applyA = Button(this).apply {
            text = "اعمال فرکانس انتخابی روی کانال A"
            setOnClickListener { setFrequencyA(selectedBankFrequency); statusText.text = "فرکانس بانک روی کانال A تنظیم شد" }
        }
        val applyB = Button(this).apply {
            text = "اعمال فرکانس انتخابی روی کانال B"
            setOnClickListener { setFrequencyB(selectedBankFrequency); statusText.text = "فرکانس بانک روی کانال B تنظیم شد" }
        }
        card.addView(applyA, matchWrap()); card.addView(applyB, matchWrap())
        val note = TextView(this).apply {
            text = "مقادیر بانک مطابق فهرست ثبت‌شده شما هستند. فرکانس‌های بالاتر از محدوده صوتی سخت‌افزار ممکن است از خروجی AUX قابل بازتولید دقیق نباشند؛ این بانک به معنی اثبات قابلیت شناسایی مواد نیست."
            textSize = 12f; setTextColor(Color.LTGRAY); setPadding(0, dp(8), 0, 0)
        }
        card.addView(note, matchWrap())
    }

    private fun formatHz(value: Double): String = if (value == value.toLong().toDouble()) value.toLong().toString() else value.toString()

    private fun addChannelControls(base: LinearLayout, title: String, isA: Boolean) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        val cardLp = matchWrap().apply { topMargin = dp(12) }
        base.addView(card, cardLp)

        val heading = TextView(this).apply {
            text = title
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(gold)
            gravity = Gravity.CENTER
        }
        card.addView(heading, matchWrap())

        val waveLabel = TextView(this).apply {
            text = "نوع موج ${if (isA) "کانال A" else "کانال B"}"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(4))
        }
        card.addView(waveLabel, matchWrap())

        val waveSelector = Spinner(this).apply {
            val labels = Waveform.values().map { it.label }
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, labels)
            setSelection(if (isA) waveformA.ordinal else waveformB.ordinal)
            setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (isA) waveformA = Waveform.values()[position] else waveformB = Waveform.values()[position]
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            })
        }
        card.addView(waveSelector, matchWrap())

        val value = TextView(this).apply {
            text = "${formatHz(if (isA) frequencyA else frequencyB)} Hz"
            textSize = 27f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        card.addView(value, matchWrap())
        if (isA) frequencyTextA = value else frequencyTextB = value

        val range = TextView(this).apply {
            text = "فرکانس مستقل: ۱۰ تا ۲۰ کیلوهرتز"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        card.addView(range, matchWrap())

        val freqSeek = SeekBar(this).apply {
            max = 10000
            progress = ((if (isA) frequencyA else frequencyB) - 10000).toInt().coerceIn(0, 10000)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val hz = 10000 + p
                        if (isA) setFrequencyA(hz.toDouble()) else setFrequencyB(hz.toDouble())
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        card.addView(freqSeek, matchWrap())
        if (isA) seekA = freqSeek else seekB = freqSeek

        val volLabel = TextView(this).apply {
            text = "شدت صدای ${if (isA) "کانال A" else "کانال B"}"
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        card.addView(volLabel, matchWrap())
        val volume = SeekBar(this).apply {
            max = 80
            progress = 25
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (isA) amplitudeA = (p / 100f).coerceIn(0f, 0.8f)
                    else amplitudeB = (p / 100f).coerceIn(0f, 0.8f)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        card.addView(volume, matchWrap())
    }

    private fun setFrequencyA(hz: Double) {
        scanEnabled = false
        if (::scanButton.isInitialized) scanButton.text = "شروع اسکن خودکار کانال A"
        frequencyA = hz
        if (::frequencyTextA.isInitialized) frequencyTextA.text = "${formatHz(frequencyA)} Hz"
        if (::seekA.isInitialized) seekA.progress = (frequencyA - 10000).toInt().coerceIn(0, 10000)
    }

    private fun setFrequencyB(hz: Double) {
        frequencyB = hz
        if (::frequencyTextB.isInitialized) frequencyTextB.text = "${formatHz(frequencyB)} Hz"
        if (::seekB.isInitialized) seekB.progress = (frequencyB - 10000).toInt().coerceIn(0, 10000)
    }

    private fun startTone() {
        if (running.get()) return
        val sampleRate = 48000
        val minBuffer = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuffer <= 0) {
            statusText.text = "خطا در راه‌اندازی خروجی استریو"
            return
        }
        val bufferSize = maxOf(minBuffer, 8192)
        val audio = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        track = audio
        running.set(true)
        startButton.text = "توقف تولید دوکاناله"
        statusText.text = "کانال A چپ و کانال B راست در حال پخش هستند"
        audio.play()

        worker = Thread {
            val frames = 2048
            val samples = ShortArray(frames * 2)
            var phaseA = 0.0
            var phaseB = 0.0
            var lastUiUpdate = 0L
            while (running.get()) {
                if (scanEnabled) {
                    val elapsed = ((System.nanoTime() - scanStartedNanos) / 1_000_000_000.0) % 20.0
                    val fraction = if (elapsed <= 10.0) elapsed / 10.0 else (20.0 - elapsed) / 10.0
                    frequencyA = 10000.0 + fraction * 10000.0
                    val now = System.nanoTime()
                    if (now - lastUiUpdate >= 100_000_000L) {
                        val shown = frequencyA
                        runOnUiThread {
                            if (scanEnabled) {
                                frequencyTextA.text = "${formatHz(shown)} Hz"
                                seekA.progress = (shown - 10000).toInt().coerceIn(0, 10000)
                            }
                        }
                        lastUiUpdate = now
                    }
                }

                val hzA = frequencyA
                val hzB = frequencyB
                val ampA = amplitudeA
                val ampB = amplitudeB
                val shapeA = waveformA
                val shapeB = waveformB
                val stepA = 2.0 * PI * hzA / sampleRate
                val stepB = 2.0 * PI * hzB / sampleRate
                for (i in 0 until frames) {
                    samples[i * 2] = (waveValue(phaseA, shapeA) * ampA * Short.MAX_VALUE)
                        .toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort() // Left: A
                    samples[i * 2 + 1] = (waveValue(phaseB, shapeB) * ampB * Short.MAX_VALUE)
                        .toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort() // Right: B
                    phaseA += stepA
                    phaseB += stepB
                    if (phaseA >= 2.0 * PI) phaseA -= 2.0 * PI
                    if (phaseB >= 2.0 * PI) phaseB -= 2.0 * PI
                }
                try { audio.write(samples, 0, samples.size) } catch (_: Exception) { break }
            }
        }.also { it.start() }
    }

    private fun waveValue(phase: Double, shape: Waveform): Double = when (shape) {
        Waveform.SINE -> sin(phase)
        Waveform.SQUARE -> if (phase < PI) 1.0 else -1.0
        Waveform.SAWTOOTH -> (phase / PI) - 1.0
    }

    private fun stopTone() {
        running.set(false)
        try { worker?.join(300) } catch (_: InterruptedException) {}
        worker = null
        try { track?.pause(); track?.flush(); track?.stop(); track?.release() } catch (_: Exception) {}
        track = null
        if (::startButton.isInitialized) startButton.text = "شروع تولید دوکاناله"
        if (::statusText.isInitialized) statusText.text = if (scanEnabled) "اسکن آماده است؛ برای شنیدن خروجی شروع را بزنید" else "متوقف"
    }

    override fun onPause() {
        scanEnabled = false
        if (::scanButton.isInitialized) scanButton.text = "شروع اسکن خودکار کانال A"
        stopTone()
        super.onPause()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
